<?php
include '../koneksi.php'; // Sisipkan file koneksi.php untuk mengakses variabel $namaUser
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <title>Restoran Suka Bumi</title>
    <meta content="width=device-width, initial-scale=1.0" name="viewport">
    <meta content="" name="keywords">
    <meta content="" name="description">

    <!-- Favicon -->
    <link href="assets/img/favicon.ico" rel="icon">

    <!-- Google Web Fonts -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Heebo:wght@400;500;600;700&display=swap" rel="stylesheet">

    <!-- Icon Font Stylesheet -->
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.10.0/css/all.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.4.1/font/bootstrap-icons.css" rel="stylesheet">

    <!-- Libraries Stylesheet -->
    <link href="../assets/lib/owlcarousel/assets/owl.carousel.min.css" rel="stylesheet">
    <link href="../assets/lib/tempusdominus/css/tempusdominus-bootstrap-4.min.css" rel="stylesheet" />

    <!-- Customized Bootstrap Stylesheet -->
    <link href="../assets/css/bootstrap.min.css" rel="stylesheet">

    <!-- Template Stylesheet -->
    <link href="../assets/css/style.css" rel="stylesheet">
    <style>
        .orangeee {
            background-color: #fd6a01;
            /* Ganti warna background menjadi orange */
        }
    </style>
</head>

<body>
    <!-- Content Start -->
    <div class="orangeee">
        <!-- Navbar Start -->

        <nav class="sb-topnav navbar navbar-expand navbar-dark bg-dark">
            <!-- Navbar Brand-->
            <a class="navbar-brand ps-3" href="index.html">
                <bold> RESTORAN SUKA BUMI </bold>
            </a>
            <form class="d-none d-md-inline-block form-inline ms-auto me-0 me-md-3 my-2 my-md-0">
            </form>
            <!-- Navbar-->
            <ul class="navbar-nav ms-auto ms-md-0 me-3 me-lg-4">
                <div class="navbar-nav w-100">
                    <a href="admin.php" class="nav-item nav-link active">
                        <i class="fas fa-box me-2"></i>Entri Menu</a>
                    <a href="Meja/meja.php" class="nav-item nav-link">
                        <i class="fas fa-chair me-2"></i>Entri Meja</a>

                </div>
                <li class="nav-item dropdown">
                    <a class="nav-link dropdown-toggle" id="navbarDropdown" href="#" role="button"
                        data-bs-toggle="dropdown" aria-expanded="false"><i class="fas fa-user fa-fw"></i></a>
                    <ul class="dropdown-menu dropdown-menu-end" aria-labelledby="navbarDropdown">
                        <li><a class="dropdown-item" href="../index.php">Logout</a></li>
                    </ul>
                </li>
            </ul>
        </nav>

        <!-- Navbar End -->

        <!-- Recent Sales Start -->
        <div class="container-fluid pt-4 px-0">
            <div class="bg-light text-center rounded p-4">
                <div class="d-flex align-items-center justify-content-between mb-4">
                    <h6 class="mb-0">DATA MENU</h6>
                    <a href="Barang/buatMenu.php" class="btn btn-primary">Tambah Menu</a>
                </div>
                <div class="table-responsive">
                    <table class="table text-start align-middle table-bordered table-hover mb-0">
                        <thead>
                            <tr class="text-dark">
                                <th scope="col">No</th>
                                <th scope="col">Nama Menu</th>
                                <th scope="col">Harga</th>
                                <th scope="col">Action</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php
                            // Sisipkan file koneksi.php untuk mengakses database
                            include '../koneksi.php';

                            // Lakukan query untuk mengambil data dari tabel menu
                            $query = "SELECT * FROM menu";
                            $result = $koneksi->query($query);

                            // Jika query berhasil dieksekusi dan mendapatkan setidaknya satu baris data
                            if ($result && $result->num_rows > 0) {
                                $no = 1;
                                // Lakukan iterasi untuk menampilkan data ke dalam tabel HTML
                                while ($row = $result->fetch_assoc()) {
                                    ?>
                                    <tr>
                                        <td>
                                            <?php echo $no++; ?>
                                        </td>
                                        <td>
                                            <?php echo $row['namaMenu']; ?>
                                        </td>
                                        <td>Rp.
                                            <?php echo number_format($row['harga'], 0, ',', '.'); ?>
                                        </td>
                                        <td>
                                            <button type="button" class="btn btn-warning btn-sm edit-btn"
                                                onclick="window.location.href='Barang/editMenu.php?idMenu=<?php echo $row['idMenu']; ?>'"
                                                data-id="<?php echo $row['idMenu']; ?>"
                                                data-nama="<?php echo $row['namaMenu']; ?>"
                                                data-harga="<?php echo $row['harga']; ?>">Edit</button>
                                            <!-- Modal Delete -->
                                            <button type="button" class="btn btn-danger btn-sm" data-bs-toggle="modal"
                                                data-bs-target="#hapusModal<?php echo $row['idMenu']; ?>">Delete</button>
                                            <!-- Modal Delete End -->
                                        </td>
                                    </tr>
                                    <!-- Modal Delete -->
                                    <div class="modal fade" id="hapusModal<?php echo $row['idMenu']; ?>" tabindex="-1"
                                        aria-labelledby="hapusModalLabel" aria-hidden="true">
                                        <div class="modal-dialog">
                                            <div class="modal-content">
                                                <div class="modal-header">
                                                    <h5 class="modal-title" id="hapusModalLabel">Konfirmasi Hapus</h5>
                                                    <button type="button" class="btn-close" data-bs-dismiss="modal"
                                                        aria-label="Close"></button>
                                                </div>
                                                <div class="modal-body">
                                                    <p>Apakah Anda yakin ingin menghapus data ini?</p>
                                                </div>
                                                <div class="modal-footer">
                                                    <button type="button" class="btn btn-secondary"
                                                        data-bs-dismiss="modal">Close</button>
                                                    <a href="Barang/hapusMenu.php?idMenu=<?php echo $row['idMenu']; ?>"
                                                        class="btn btn-danger btn-circle">
                                                        <i class="fas fa-trash"></i>
                                                    </a>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <!-- Modal Delete End -->
                                    <?php
                                }
                            } else {
                                // Jika query tidak mengembalikan hasil
                                echo "<tr><td colspan='4'>Tidak ada data yang tersedia</td></tr>";
                            }
                            ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
        <!-- Recent Sales End -->




        <!-- Footer End -->
    </div>
    <!-- Content End -->



    <!-- JavaScript Libraries -->
    <script src="https://code.jquery.com/jquery-3.4.1.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0/dist/js/bootstrap.bundle.min.js"></script>
    <script src="../assets/lib/chart/chart.min.js"></script>
    <script src="../assets/lib/easing/easing.min.js"></script>
    <script src="../assets/lib/waypoints/waypoints.min.js"></script>
    <script src="../assets/lib/owlcarousel/owl.carousel.min.js"></script>
    <script src="../assets/lib/tempusdominus/js/moment.min.js"></script>
    <script src="../assets/lib/tempusdominus/js/moment-timezone.min.js"></script>
    <script src="../assets/lib/tempusdominus/js/tempusdominus-bootstrap-4.min.js"></script>



</body>

</html>



</body>

</html>